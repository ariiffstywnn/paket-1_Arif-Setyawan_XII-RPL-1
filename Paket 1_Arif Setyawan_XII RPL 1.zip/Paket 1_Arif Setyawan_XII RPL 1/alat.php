<?php
<link rel="stylesheet" href="style.css">
include 'config/koneksi.php';
$data = mysqli_query($conn, "
SELECT alat.*, kategori.nama_kategori 
FROM alat 
LEFT JOIN kategori ON alat.kategori_id = kategori.id_kategori
");
?>

<link rel="stylesheet" href="assets/style.css">

<div class="sidebar">
    <h2>Menu</h2>
    <a href="dashboard_admin.php">Dashboard</a>
    <a href="#">User</a>
    <a href="#">Alat</a>
    <a href="#">Kategori</a>
    <a href="logout.php">Logout</a>
</div>

<div class="main">

    <div class="card">
        <h2>Data Alat</h2>

        <button class="btn btn-tambah">+ Tambah Alat</button>

        <table>
            <tr>
                <th>No</th>
                <th>Nama Alat</th>
                <th>Kategori</th>
                <th>Stok</th>
                <th>Aksi</th>
            </tr>

            <?php $no=1; while($d=mysqli_fetch_array($data)){ ?>
            <tr>
                <td><?= $no++ ?></td>
                <td><?= $d['nama_alat'] ?></td>
                <td><?= $d['nama_kategori'] ?></td>
                <td><?= $d['stok'] ?></td>
                <td>
                    <button class="btn btn-edit">Edit</button>
                    <button class="btn btn-hapus">Hapus</button>
                </td>
            </tr>
            <?php } ?>
        </table>

    </div>

</div>