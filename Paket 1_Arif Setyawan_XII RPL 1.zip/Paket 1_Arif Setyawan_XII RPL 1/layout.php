<link rel="stylesheet" href="../style.css">

<div class="sidebar">
<h2>⚡ Menu</h2>

<a href="dashboard.php">Dashboard</a>

<?php if($_SESSION['role']=="admin"){ ?>
<a href="user.php">User</a>
<a href="alat.php">Alat</a>
<a href="kategori.php">Kategori</a>
<?php } ?>

<?php if($_SESSION['role']=="petugas"){ ?>
<a href="../petugas/peminjaman.php">Peminjaman</a>
<a href="../petugas/pengembalian.php">Pengembalian</a>
<?php } ?>

<?php if($_SESSION['role']=="peminjam"){ ?>
<a href="../peminjam/alat.php">Pinjam</a>
<a href="../peminjam/riwayat.php">Riwayat</a>
<?php } ?>

<a href="../logout.php">Logout</a>
</div>

<div class="main">