<?phpsession_start(); ?>
<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="style.css">

<div class="login-box">
    <h2>Login Sistem</h2>

    <?php if(isset($_GET['error'])){ ?>
        <p style="color:red;">Login gagal</p>
    <?php } ?>

    <form action="proses_login.php" method="POST">
        <input type="text" name="username" placeholder="Username">
        <input type="password" name="password" placeholder="Password">
        <button class="btn btn-tambah">Login</button>
    </form>
</div>