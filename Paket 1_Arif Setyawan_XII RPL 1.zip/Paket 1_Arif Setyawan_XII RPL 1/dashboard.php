<?php
session_start();
require_once "../koneksi.php";

if(!isset($_SESSION['role'])){
    header("Location: ../login.php");
    exit;
}

require_once "layout.php";
?>

<div class="card">
    <h2>Dashboard</h2>
    <p>Selamat datang admin</p>
</div>

</div>