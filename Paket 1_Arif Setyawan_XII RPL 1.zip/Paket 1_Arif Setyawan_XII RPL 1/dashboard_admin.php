<?php session_start();

if(!isset($_SESSION['nama'])){
    header("Location: login.php");
    exit;
}


include 'config/koneksi.php';
?>
<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="style.css">

<div class="sidebar">
    <h2>Menu</h2>
    <a href="#">Dashboard</a>
    <a href="#">User</a>
    <a href="alat.php">Alat</a>
    <a href="#">Kategori</a>
    <a href="logout.php">Logout</a>
</div>

<div class="main">

    <div class="card">
        <h2>Dashboard Admin</h2>
        <p>Halo, <?= $_SESSION['nama']; ?></p>
    </div>

</div>