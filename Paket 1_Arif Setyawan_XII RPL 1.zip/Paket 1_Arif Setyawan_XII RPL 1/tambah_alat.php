<?php
session_start();
include __DIR__ . '/config/koneksi.php';

$kategori = mysqli_query($conn, "SELECT * FROM kategori");
?>

<link rel="stylesheet" href="assets/style.css">

<div class="main">
    <div class="card">
        <h2>Tambah Alat</h2>

        <form action="proses_tambah_alat.php" method="POST">
            <input type="text" name="nama_alat" placeholder="Nama Alat" required><br><br>

            <select name="kategori_id">
                <?php while($k=mysqli_fetch_array($kategori)){ ?>
                    <option value="<?= $k['id_kategori'] ?>">
                        <?= $k['nama_kategori'] ?>
                    </option>
                <?php } ?>
            </select><br><br>

            <input type="number" name="stok" placeholder="Stok"><br><br>

            <button class="btn btn-tambah">Simpan</button>
        </form>
    </div>
</div>