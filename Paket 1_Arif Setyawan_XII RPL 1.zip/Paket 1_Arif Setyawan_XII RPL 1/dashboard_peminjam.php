<?php
session_start();
if($_SESSION['role'] != 'peminjam'){
    header("Location: login.php");
}
?>

<link rel="stylesheet" href="style.css">

<div class="container">

    <div class="sidebar">
        <h2>Peminjam</h2>
        <a href="#">Dashboard</a>
        <a href="#">Pinjam Alat</a>
        <a href="#">Status</a>
        <a href="logout.php">Logout</a>
    </div>

    <div class="main">
        <div class="navbar">
            <span>Dashboard User</span>
            <span><?= $_SESSION['nama']; ?></span>
        </div>

        <div class="content">

            <div class="card">
                <h3>Selamat Datang</h3>
                <p>Silakan ajukan peminjaman alat</p>
            </div>

        </div>
    </div>

</div>