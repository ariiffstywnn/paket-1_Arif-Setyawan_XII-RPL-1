<?php
session_start();
include __DIR__ . '/config/koneksi.php';

$username = $_POST['username'];
$password = $_POST['password'];

$data = mysqli_fetch_assoc(mysqli_query($conn,
"SELECT * FROM user WHERE username='$username' AND password='$password'"
));

if($data){
    $_SESSION['nama'] = $data['nama'];
    $_SESSION['role'] = $data['role'];

    header("Location: dashboard_admin.php");
} else {
    header("Location: login.php?error=1");
}