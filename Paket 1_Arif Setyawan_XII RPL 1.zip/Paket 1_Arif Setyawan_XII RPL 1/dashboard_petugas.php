<?php
session_start();
if($_SESSION['role'] != 'petugas'){
    header("Location: login.php");
}
?>

<link rel="stylesheet" href="style.css">

<div class="container">

    <div class="sidebar">
        <h2>Petugas</h2>
        <a href="#">Dashboard</a>
        <a href="#">Validasi Peminjaman</a>
        <a href="#">Pengembalian</a>
        <a href="logout.php">Logout</a>
    </div>

    <div class="main">
        <div class="navbar">
            <span>Dashboard Petugas</span>
            <span><?= $_SESSION['nama']; ?></span>
        </div>

        <div class="content">

            <div class="card">
                <h3>Selamat Datang</h3>
                <p>Kelola validasi peminjaman</p>
            </div>

        </div>
    </div>

</div>